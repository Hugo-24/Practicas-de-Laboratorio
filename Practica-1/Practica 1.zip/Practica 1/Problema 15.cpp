#include <iostream>

using namespace std;
//Problema 15. Empezando con el número 1 y moviéndose hacia la izquierda y en sentido horario se genera una espiral de números como la siguiente:
int main() {
    int n;
    cout << "Ingrese un número impar: ";
    cin >> n;

    if (n % 2 == 0) {
        cout << "El número debe ser impar." << endl;
        return 1;
    }
    int suma_diagonal = 1;
    int numero = 1;

    for (int capa = 1; capa <= n / 2; capa++) {
        for (int i = 0; i < 4; i++) {
            numero += capa * 2;
            suma_diagonal += numero;
        }
    }

    int matriz[n][n];
    int x = n / 2, y = n / 2;
    int dx[] = {1, 0, -1, 0};
    int dy[] = {0, -1, 0, 1};
    int pasos = 1, direccion = 0;
    
    numero = 1;
    matriz[y][x] = numero;

    while (numero < n * n) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < pasos; j++) {
                x += dx[direccion];
                y += dy[direccion];
                numero++;
                matriz[y][x] = numero;
                if (numero == n * n) break;
            }
            direccion = (direccion + 1) % 4;
        }
        pasos++;
    }

    cout << "Espiral de " << n << "x" << n << ":" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << "\t";
        }
        cout << endl;
    }

    cout << "En una espiral de " << n << "x" << n << ", la suma es: " << suma_diagonal << "." << endl;
    return 0;
}